package model;

import java.util.Date;

// Plain Java object that holds booking data
// No logic here, just getters and setters
public class Booking {

    private int bookingId;
    private String guestName;
    private String guestPhone;
    private int roomId;
    private Date checkInDate;
    private Date checkOutDate;
    private String status;

    // Empty constructor
    public Booking() {}

    // Constructor with all fields
    public Booking(int bookingId, String guestName, String guestPhone, int roomId, Date checkInDate, Date checkOutDate, String status) {
        this.bookingId = bookingId;
        this.guestName = guestName;
        this.guestPhone = guestPhone;
        this.roomId = roomId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.status = status;
    }

    // Getters
    public int getBookingId() { return bookingId; }
    public String getGuestName() { return guestName; }
    public String getGuestPhone() { return guestPhone; }
    public int getRoomId() { return roomId; }
    public Date getCheckInDate() { return checkInDate; }
    public Date getCheckOutDate() { return checkOutDate; }
    public String getStatus() { return status; }

    // Setters
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }
    public void setGuestName(String guestName) { this.guestName = guestName; }
    public void setGuestPhone(String guestPhone) { this.guestPhone = guestPhone; }
    public void setRoomId(int roomId) { this.roomId = roomId; }
    public void setCheckInDate(Date checkInDate) { this.checkInDate = checkInDate; }
    public void setCheckOutDate(Date checkOutDate) { this.checkOutDate = checkOutDate; }
    public void setStatus(String status) { this.status = status; }
}
